#!/usr/bin/env python3
"""Build the complete health-app.html from modules."""
import os

MOD_DIR = "/sessions/6a1ed7af3fc2f2eda7fbbf13/workspace/6.小程序原型/modules"
OUT_DIR = "/sessions/6a1ed7af3fc2f2eda7fbbf13/workspace/6.小程序原型"

# Assembly order (must match the original file exactly)
ORDER = [
    "head",
    "skeleton-start",
    "onboarding",
    "scroll-start",
    "page-home",
    "page-tracking",
    "page-service",
    "page-rewards",
    "page-profile",
    "page-diet-record",
    "food-selector",
    "bottom-nav",
    "script",
    "skeleton-end",
]

output = []
for name in ORDER:
    path = os.path.join(MOD_DIR, f"{name}.html")
    if not os.path.exists(path):
        print(f"WARNING: {path} not found!")
        continue
    with open(path) as f:
        output.append(f.read())

result = "".join(output)

out_path = os.path.join(OUT_DIR, "health-app_v10.html")
with open(out_path, "w") as f:
    f.write(result)

print(f"Built: {out_path}")
print(f"Size: {len(result)} chars")

# Verify JavaScript syntax
import re
js_match = re.search(r"<script>(.*?)</script>", result, re.DOTALL)
if js_match:
    js_code = js_match.group(1)
    try:
        compile(js_code, "<string>", "exec")
        print("JS syntax: OK ✓")
    except SyntaxError as e:
        print(f"JS syntax: ERROR - {e}")

# Verify div depth
depth = 0
for i, ch in enumerate(result):
    if result[i:i+4] == '<div' and (i+4 >= len(result) or result[i+4] in ' \n\r\t>'):
        depth += 1
    elif result[i:i+6] == '</div>':
        depth -= 1
print(f"Div depth: {depth} (should be 0)")
